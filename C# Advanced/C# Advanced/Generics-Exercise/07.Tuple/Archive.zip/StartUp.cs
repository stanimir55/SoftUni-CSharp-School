﻿namespace _07.Tuple
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] personInfo = Console.ReadLine().Split();
            string[] alcholicPerson = Console.ReadLine().Split();
            string[] values = Console.ReadLine().Split();

            string personName = personInfo[0] + " " + personInfo[1];
            string personTown = personInfo[2];

            string alcholicName = alcholicPerson[0];
            int alcholicLiters = int.Parse(alcholicPerson[1]);

            int integerValue = int.Parse(values[0]);
            double doubleValue = double.Parse(values[1]);

            var tuple = new MyTuple<string, string>(personName, personTown);
            var tuple1 = new MyTuple<string, int>(alcholicName, alcholicLiters);
            var tuple2 = new MyTuple<int, double>(integerValue, doubleValue);

            Console.WriteLine($"{tuple.Item1} -> {tuple.Item2}");
            Console.WriteLine($"{tuple1.Item1} -> {tuple1.Item2}");
            Console.WriteLine($"{tuple2.Item1} -> {tuple2.Item2}");
        }
    }

    /*
Adam Smith California
Mark 2
23 21.23212321
     */
}